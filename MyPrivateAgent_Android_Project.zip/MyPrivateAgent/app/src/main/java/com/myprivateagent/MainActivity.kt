package com.myprivateagent

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import com.myprivateagent.data.AppSettings
import com.myprivateagent.ui.AgentApp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val settings = AppSettings(this)

        setContent {
            val baseUrl by settings.baseUrlFlow.collectAsState(initial = "")
            val pinEnabled by settings.pinEnabledFlow.collectAsState(initial = false)

            AgentApp(
                settings = settings,
                initialBaseUrl = baseUrl,
                pinEnabled = pinEnabled
            )
        }
    }
}
